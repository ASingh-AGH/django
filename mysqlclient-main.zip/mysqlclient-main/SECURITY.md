# Security Policy

## Supported Versions

2.1.x

## Reporting a Vulnerability

email: songofacandy@gmail.com
